package lk.ijse.repository;

public class CustomerRepo {
}
