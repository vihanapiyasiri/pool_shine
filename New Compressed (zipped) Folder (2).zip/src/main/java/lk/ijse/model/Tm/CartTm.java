package lk.ijse.model.Tm;

import com.jfoenix.controls.JFXButton;

public class CartTm {
    public CartTm(String code, String description, int qty, double unitPrice, double total) {

    }

    public int getQty() {
        return 0;
    }

    public void setQty(int qty) {

    }

    public void setTotal(double total) {

    }
}
