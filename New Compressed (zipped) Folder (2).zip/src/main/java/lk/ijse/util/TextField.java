package lk.ijse.util;

public enum TextField {
    ID,EMAIL,PHONE,CONTACT
}
